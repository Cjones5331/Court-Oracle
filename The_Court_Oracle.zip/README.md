# The Court Oracle

This is a Streamlit dashboard built to predict NBA player performance, fantasy value, and betting outcomes using deep learning, Vegas line signals, and team synergy analysis.

## How to Run

1. Clone the repository
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Launch the app:

```bash
streamlit run app.py
```

Then visit http://localhost:8501 in your browser.